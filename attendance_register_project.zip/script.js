let students = JSON.parse(localStorage.getItem("attendanceStudents")) || [];

const studentName = document.getElementById("studentName");
const searchInput = document.getElementById("searchInput");
const attendanceTable = document.getElementById("attendanceTable");
const totalStudents = document.getElementById("totalStudents");
const totalPresent = document.getElementById("totalPresent");
const totalAbsent = document.getElementById("totalAbsent");
const emptyMessage = document.getElementById("emptyMessage");
const message = document.getElementById("message");

function saveToLocalStorage() {
  localStorage.setItem("attendanceStudents", JSON.stringify(students));
}

function displayStudents(list = students) {
  attendanceTable.innerHTML = "";

  if (list.length === 0) {
    emptyMessage.style.display = "block";
  } else {
    emptyMessage.style.display = "none";
  }

  list.forEach((student, index) => {
    const actualIndex = students.indexOf(student);

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${index + 1}</td>
      <td>${escapeHTML(student.name)}</td>
      <td>
        <button class="status-btn ${
          student.present ? "status-present" : "status-absent"
        }" onclick="toggleAttendance(${actualIndex})">
          ${student.present ? "Present" : "Absent"}
        </button>
      </td>
      <td>
        <button class="edit-btn" onclick="editStudent(${actualIndex})">Edit</button>
        <button class="delete-btn" onclick="deleteStudent(${actualIndex})">Delete</button>
      </td>
    `;

    attendanceTable.appendChild(row);
  });

  updateCounts();
}

function updateCounts() {
  totalStudents.textContent = students.length;
  totalPresent.textContent = students.filter(s => s.present).length;
  totalAbsent.textContent = students.filter(s => !s.present).length;
}

function addStudent() {
  const name = studentName.value.trim();

  if (name === "") {
    showMessage("Please enter a student name.");
    return;
  }

  const exists = students.some(
    s => s.name.toLowerCase() === name.toLowerCase()
  );

  if (exists) {
    showMessage("That student is already on the register.");
    return;
  }

  students.push({
    name: name,
    present: false
  });

  saveToLocalStorage();
  studentName.value = "";
  displayStudents();
  showMessage("Student added successfully.");
}

function toggleAttendance(index) {
  students[index].present = !students[index].present;
  saveToLocalStorage();
  displayStudents();
  showMessage("Attendance record updated.");
}

function editStudent(index) {
  const newName = prompt("Edit student name:", students[index].name);

  if (newName === null) return;

  const cleanName = newName.trim();

  if (cleanName === "") {
    showMessage("Student name cannot be empty.");
    return;
  }

  students[index].name = cleanName;
  saveToLocalStorage();
  displayStudents();
  showMessage("Student record edited.");
}

function deleteStudent(index) {
  if (confirm(`Remove ${students[index].name} from the register?`)) {
    students.splice(index, 1);
    saveToLocalStorage();
    displayStudents();
    showMessage("Student removed.");
  }
}

function searchStudents() {
  const term = searchInput.value.toLowerCase().trim();

  const filtered = students.filter(student =>
    student.name.toLowerCase().includes(term)
  );

  displayStudents(filtered);
}

function saveAttendance() {
  saveToLocalStorage();
  showMessage("Attendance saved successfully in Local Storage.");
}

function clearAll() {
  if (students.length === 0) {
    showMessage("There are no records to clear.");
    return;
  }

  if (confirm("Are you sure you want to clear all attendance records?")) {
    students = [];
    saveToLocalStorage();
    displayStudents();
    showMessage("All attendance records cleared.");
  }
}

function showMessage(text) {
  message.textContent = text;
  setTimeout(() => {
    message.textContent = "";
  }, 2500);
}

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

document.getElementById("addBtn").addEventListener("click", addStudent);
document.getElementById("saveBtn").addEventListener("click", saveAttendance);
document.getElementById("clearBtn").addEventListener("click", clearAll);
searchInput.addEventListener("input", searchStudents);

studentName.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    addStudent();
  }
});

displayStudents();
